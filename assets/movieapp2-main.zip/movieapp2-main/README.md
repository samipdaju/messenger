<p align="left"> <img src="https://komarev.com/ghpvc/?username=bilguunint&label=Profile%20views&color=0e75b6&style=flat" alt="bilguunint" /> </p>

## Screenshots

<img src="https://cdn.zochil.shop/6273056d-3909-47cc-8331-7300438f5f2e.png" alt="nice Ui" class="img-fluid">

## Usage

https://www.themoviedb.org/ Register and Login get API Key from Profile > API

- All you need is here:

		git clone https://github.com/bilguunint/movieapp2.git
		
		cd movieapp2
		
		flutter run

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License
[MIT](https://choosealicense.com/licenses/mit/)
