package com.example.movieapp2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
